==========
spicemanip
==========


.. image:: https://img.shields.io/pypi/v/spicemanip.svg
        :target: https://pypi.python.org/pypi/spicemanip

.. image:: https://img.shields.io/travis/deathbybandaid/spicemanip.svg
        :target: https://travis-ci.org/deathbybandaid/spicemanip

.. image:: https://readthedocs.org/projects/spicemanip/badge/?version=latest
        :target: https://spicemanip.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




spicemanip aims to ease list and string manipulation


* Free software: MIT license
* Documentation: https://spicemanip.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
