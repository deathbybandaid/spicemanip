#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `spicemanip` package."""


import unittest

from spicemanip import spicemanip


class TestSpicemanip(unittest.TestCase):
    """Tests for `spicemanip` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
