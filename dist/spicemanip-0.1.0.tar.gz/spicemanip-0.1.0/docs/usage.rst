=====
Usage
=====

To use spicemanip in a project::

    import spicemanip
